<a href="signin.php">signin.php</a>
<a href="signout.php">signout.php<a>
<a href="list.php">list.php</a>
<a href='insert.php'>insert.php</a>