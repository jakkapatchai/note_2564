<?php session_start();
$_SESSION[t] = "";
echo '<a href=index.php>back</a>'; ?>
