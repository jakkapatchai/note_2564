<form action="check.php">
<input name=user><input name=p>
<input type=submit></form>