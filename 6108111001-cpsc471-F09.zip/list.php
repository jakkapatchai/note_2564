<?php session_start();
if(!isset($_SESSION["t"]) || strlen($_SESSION["t"]) == 0) {
echo '<a href=index.php>back</a> exit()';
}
$connect = new mysqli("127.0.0.1", "root", "", "test");
$result = $connect->query("select * from mem");
echo $result->num_rows . "<br/>";
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo  $row['u'] . $row['p'] .  $row['salary'] . $row['t'] . "<br/>";
  } }
echo '<a href=index.php>back : salary system </a>' ;
$connect->close(); ?>