<?php session_start();
if(!isset($_SESSION["t"]) || strlen($_SESSION["t"]) == 0) {
die ('<a href=index.php>back</a>');
}
$connect = new mysqli("127.0.0.1", "root", "root", "test");
$sql = "insert into mem values (0,'" .$_POST["u"] ."','" . $_POST["p"] ."','" . $_POST["salary"] ."','". $_POST["t"] ."')";
$result = $connect->query($sql);
if($result === FALSE)  echo "$sql : failed"; else echo "$sql : succeeded";
echo '<br/><a href=index.php>back</a>' ;
$connect->close(); ?>
