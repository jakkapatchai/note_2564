<?php session_start();
$connect = new mysqli("127.0.0.1", "root", "", "test");
$result = $connect->query("select * from mem");
$_SESSION["t"] = "";
if ($result->num_rows > 0) 
  while($row = $result->fetch_assoc()) {
    if($row["u"] == $_REQUEST["u"] && $row["p"] == $_REQUEST["p"]) $_SESSION["t"] = $row["t"];
  }
echo '<a href="index.php">back</a><br/>' . $_SESSION["t"];
$connect->close(); ?>