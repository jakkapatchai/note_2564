<form action="addrec.php" method="post">
<input name=u><input name=p><input name=salary><input name=t><input type=submit>
</from>